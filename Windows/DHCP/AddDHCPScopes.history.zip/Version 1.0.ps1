$DHCPServer="flodhcp-01.fcty.gov"
$CiscoTFTP = @("10.105.215.10","10.105.15.10","10.255.115.10")
$DHCPFile = "dhcpscopes.csv"


Import-CSV $DHCPFile | ForEach-Object {
        $name = $_.name
        $description = $_.description
        $startrange = $_.startrange
        $endrange = $_.endrange
        $subnetmask = $_.subnetmask
        $router = $_.router
        $scopeid = $_.scopeid
        $voip = $_.voip

 #   WRite-Host  'Creating DHCP Scope for: '$name
 #   Add-DhcpServerv4Scope -Name $name -Description $description -StartRange $startrange -EndRange $endrange -SubnetMask $subnetmask
 #   Set-DhcpServerv4OptionValue -ScopeId $scopeid -Router $router
#		if ("1" -eq $voip){
#    Set-DhcpServerv4OptionValue -OptionId 150 -ScopeId $scopeid -Value $CiscoTFTP
#    }
}
