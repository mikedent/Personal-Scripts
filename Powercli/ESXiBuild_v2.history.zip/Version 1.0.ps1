$VIServer = '10.94.0.25'
$vMotionIP = '10.255.253.25'
$subnetMask = '255.255.255.0'
$User = 'root'
$Pass = 'Tr!t3cH1'
#Add-PSSnapin VMware.VimAutomation.Core
Connect-VIServer -Server $VIServer  -User $User -Password $Pass

# Network Parameters
$VmnicInterface = @(
  'vmnic0', 
  'vmnic1', 
  'vmnic4', 
  'vmnic5'
)

$Uplink1 = 'vmnic0'
$uplink2 = 'vmnic1'
$uplink3 = 'vmnic4'
$uplink4 = 'vmnic5'

# Host Environment Parameters
$DomainName = 'e911.local'
$DNSSearch = 'e911.local'
$PreferredDNS = '8.8.8.8'
#$AltDNS = "x.x.x.x"
$NTPServers = ('10.255.255.225')
$EnableSsh = '1'
$License = '0M6A2-00HEP-P8194-0YCU4-3WJM5'

# Place host in Maintenace Mode
if ($HostMaintenanceMode -eq $True)
{
  #Place Host in maintenance mode
  $HostConnectionState = Get-VMHost -Name $Hostname

  #Check to see is host is already in maintenance mode. If not, place the host in maintenance mode
  if ($HostConnectionState.ConnectionState -eq 'Maintenance')
  {

  }
  ELSE
  {
    Set-VMHost -VMHost $Hostname -State Maintenance
  }
}

# Configure vSwitch0
Write-Host -Object 'Configuring vSwitch0'
$vs0 = Get-VirtualSwitch -Name vSwitch0
Add-VirtualSwitchPhysicalNetworkAdapter -VirtualSwitch $vs0 -VMHostPhysicalNic (Get-VMHostNetworkAdapter -Physical -Name $VmnicInterface[2]) -Confirm:$false

# Configure new standard vSwitch for iSCSI/vMotion
$vs1 = New-VirtualSwitch -Name 'vSwitch1' -Mtu $MTU -Nic $VmnicInterface[1], $VmnicInterface[3] -Confirm:$false

# Configure vMotion
Write-Host -Object 'Configuring vMotion'
New-VirtualPortGroup -Name 'vMotion' -VirtualSwitch $vs1 -VLanId 930 
New-VMHostNetworkAdapter -PortGroup vMotion -VirtualSwitch $vs1 -IP $vMotionIP -SubnetMask $subnetMask -VMotionEnabled: $True -Mtu -VMHost $MTU

# Configure NTP
$ESXhosts = Get-VMHost
foreach ($ESX in $ESXhosts)
{
  Write-Host -Object "Target = $ESX"
  Add-VMHostNtpServer -VMHost $ESX -NtpServer $NTPServers -Confirm:$false
  Set-VMHostService -HostService (Get-VMHostService -VMHost (Get-VMHost $ESX) | Where-Object -FilterScript {
      $_.key -eq 'ntpd'
  }) -Policy 'Automatic'
  Get-VMHostFirewallException -VMHost $ESX -Name 'NTP Client' | Set-VMHostFirewallException -Enabled:$True
  $ntpd = Get-VMHostService -VMHost $ESX | Where-Object -FilterScript {
    $_.Key -eq 'ntpd'
  }
  Restart-VMHostService -HostService $ntpd -Confirm:$false
  # Go ahead and update the time to match host time
  $t = Get-Date
  $dst = Get-VMHost | ForEach-Object -Process {
    Get-View -VIObject $_.ExtensionData.ConfigManager.DateTimeSystem
  }
  $dst.UpdateDateTime((Get-Date -Date ($t.ToUniversalTime()) -Format u))
}

# Enable/Disable SSH
if ('1' -eq $EnableSsh) 
{
  Write-Host -Object 'The SSH Service will be set to start when the hosts boots'
  Get-VMHostService |
  Where-Object -FilterScript {
    $_.Key -eq 'TSM-SSH'
  } |
  Set-VMHostService -Policy On
  Get-VMHostService |
  Where-Object -FilterScript {
    $_.Key -eq 'TSM-SSH'
  } |
  Start-VMHostService
  Get-AdvancedSetting -Entity (Get-VMHost) -Name 'UserVars.SuppressShellWarning' | Set-AdvancedSetting -Value 1 -Confirm:$false
}
Else 
{
  Write-Host -Object 'The SSH Service will remain disabled'
}
      
# Configure Licensing
$licMgr = Get-View -Id 'LicenseManager-ha-license-manager'
$licMgr.UpdateLicense($License, $null)

# Set DNS Details to ensure they have been set
$vmHostNetworkInfo = Get-VMHostNetwork
Set-VMHostNetwork -Network $vmHostNetworkInfo -DomainName $DomainName -SearchDomain $DNSSearch
Set-VMHostNetwork -Network $vmHostNetworkInfo -DnsAddress $PreferredDNS

#Restart the host to apply the timeout settings
if ($RebootHost)
{
  Restart-VMHost -VMHost $Hostname -Confirm:$false
}

Disconnect-VIServer -Server * -Confirm:$false
